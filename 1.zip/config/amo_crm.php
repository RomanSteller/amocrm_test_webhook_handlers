<?php

return [
    'sub_domain' => env('AMO_CRM_ACCOUNT_SUBDOMAIN'),
    'client_id' => env('AMO_CRM_CLIENT_ID'),
    'client_secret' => env('AMO_CRM_CLIENT_SECRET'),
    'redirect_uri' => env('AMO_CRM_REDIRECT_URI'),
];
